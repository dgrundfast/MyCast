# 🎙 MyCast — Personal AI Podcast Generator

Turn any topic into a personal podcast series, powered by Claude AI.

---

## Quick Start (Local)

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# 3. Open your browser
open http://localhost:3000
```

---

## Deploy to Replit (Free, 5 minutes)

1. Go to **replit.com** and create a free account
2. Click **Create Repl → Import from GitHub** (or paste the code manually)
3. Choose **Node.js** as the template
4. Upload all files maintaining the folder structure
5. In the Replit shell, run: `npm install`
6. Click **Run** — Replit gives you a public URL instantly
7. Share that URL with anyone — they bring their own Anthropic API key

---

## Deploy to Railway (Recommended for production)

1. Go to **railway.app** and sign up
2. Click **New Project → Deploy from GitHub**
3. Connect your GitHub repo containing this code
4. Railway auto-detects Node.js and deploys
5. Your app gets a `*.railway.app` URL in ~2 minutes

**Cost:** Free tier includes $5/month credit — enough for a prototype with light traffic.

---

## Deploy to Render

1. Go to **render.com**
2. Click **New → Web Service**
3. Connect your GitHub repo
4. Set:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
5. Click **Create Web Service**

---

## Folder Structure

```
mycast/
├── server/
│   └── index.js          # Express server — handles Anthropic API calls
├── public/
│   ├── index.html         # App shell
│   ├── css/
│   │   └── app.css        # All styles
│   └── js/
│       ├── voices.js      # Voice selection engine
│       └── app.js         # Main application logic
├── package.json
└── README.md
```

---

## Upgrading to ElevenLabs Voice

When you're ready for professional-quality voices:

1. Get an API key at **elevenlabs.io**
2. In `server/index.js`, add a new route `/api/synthesize`
3. In `public/js/voices.js`, replace `VoiceEngine.pickVoice()` with a fetch to `/api/synthesize` that returns an audio blob
4. In `public/js/app.js`, replace `SpeechSynthesisUtterance` with an `<audio>` element playing the ElevenLabs blob

The voice engine was designed for this swap — it's a single-file change.

---

## Environment Variables (Optional)

If you want to hardcode the API key server-side instead of having users provide their own:

```bash
ANTHROPIC_API_KEY=sk-ant-...
```

Then in `server/index.js`, replace `req.body.apiKey` with `process.env.ANTHROPIC_API_KEY`.

---

## What's Next

- [ ] User accounts (save and revisit your casts)
- [ ] Public cast sharing with unique URLs
- [ ] ElevenLabs voice integration
- [ ] RSS feed export (listen in Apple Podcasts / Spotify)
- [ ] Mobile app (React Native)
- [ ] Multi-AI support (GPT-4, Gemini)
